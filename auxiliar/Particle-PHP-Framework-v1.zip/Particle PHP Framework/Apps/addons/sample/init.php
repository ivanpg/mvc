<?php
namespace Particle\Addons;
use Particle\Core;

    class sampleAddons extends Core\Controller {
   
    function __construct() {
        /*setting addons*/
            
            $nameAddons= 'sample';
            
            Core\App::getInstance()->setAppCurrentAddons($nameAddons);
            
            parent::__construct(true);
            
        /* end setting addons*/
    }
    
    public function sample(){
    // $this->_model        ---- MODELO DEL CONTROLADOR QUE LLAMO AL ADDONS ACTUAL
    // $this->_modelAddons  ---- MODELO DEL ADDONS ACTUAL
    // $this->_args         ---- ARGUMENTOS ENVIADOS AL CONTROLADOR QUE LLAMO AL ADDONS ACTUAL
    // $this->_view         ---- VISTA DEL CONTROLADOR QUE LLAMO AL ADDONS ACTUAL
    // $this->_viewAddons   ---- NO SOPORTADO
        
        
        $var = "Hola Mundo";
        
        return $var;
    }
    
}