<?php
namespace Particle\Addons;
use Particle\Core;

class sampleModelAddons extends Core\Model {
    
    public function __construct()
    {
        parent::__construct();
        
        if(!$this->_db){
            throw new \Exception('Error: Enable DB');
        }
        
    }
    
    public function sampleModel()
    {
        // USE class \PDO
    }
   
}

?>
