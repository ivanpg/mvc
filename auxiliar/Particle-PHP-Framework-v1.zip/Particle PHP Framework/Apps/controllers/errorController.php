<?php
namespace Particle\Apps;
use Particle\Core;

class errorController extends Core\Controller {

    public function __construct() {
        parent::__construct();
    
        $this->_view->setCss(array('index'));
        
    }
    
    public function index()
    {
        $this->_view->assign('title', 'Error');
        $this->_view->assign('message', $this->_getError());
        $this->_view->show();
    }
    
    public function message($errorKey = false)
    {
        $this->_view->assign('title', 'Error');
        $this->_view->assign('message', $this->_getError($errorKey));
        $this->_view->show();
    }
    
    private function _getError($errorKey = false)
    {
        if($errorKey){
            $errorKey = $this->filterInt($errorKey);
        }
        else{
            $errorKey = 'default';
        }        
        
        $error = array();
        $error['default'] = 'There was an error and the page can not be shown';
        $error['5050'] = 'Restricted access!';
        $error['8080'] = 'Session time expired!';
        
        if(array_key_exists($errorKey, $error)){
            return $error[$errorKey];
        }
        else{
            return $error['default'];
        }
    }
}
