<?php
namespace Particle\Apps;
use Particle\Core;

class indexController extends Core\Controller {
    
    public function __construct() {
        
        parent::__construct();
        
        $this->_view->setCss(array('index'));
        
    }
    
    public function index(){

        $this->_view->show();
    
    }
    
}