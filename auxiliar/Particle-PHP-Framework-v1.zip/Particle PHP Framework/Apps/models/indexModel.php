<?php
namespace Particle\Apps;
use Particle\Core;

class indexModel extends Core\Model 
{
    public function __construct() {
        parent::__construct();
    }

    public function getNews()
    {
        if(!$this->_db){
            throw new \Exception('Error: Enable DB');
        }
        
        /*$newsRes = $this->_db->query('select * from news');
        
        if($newsRes){
            return $newsRes->fetchAll();
        }else{
            return false;
        }*/
        
    }
    
}