<?php
namespace Particle\Core;
/**
 *  @name App
 *  @category Particle\Core
 *  @author dertin
 *  
 *    
 *  Esta class se encarga de contener información sobre 
 *  el controller, method y args en proceso.
 *  
 **/
final class App {
    
    private  $_controller = false;
    private  $_method = false;
    private  $_args = false;
    private  $_request = false;
    private  $_currentAddons = false;
    
    private static $instance = null;
    
    public static function getInstance()
    {
        if ( is_null( self::$instance ) )
        {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public final function getAppCurrentAddons(){
         return $this->_currentAddons;
    }
    
    public final function getAppController(){
        return $this->_controller;
    }
    
    public final  function getAppMethod(){
        return $this->_method;
    }
    
    public final  function getAppArgs(){
        return $this->_args;
    }
    
    public final  function getAppRequest(){
        return $this->_request;
    }
    
    
    public final function setAppCurrentAddons($CurrentAddons){
         $this->_currentAddons = $CurrentAddons;
    }
    
    public final  function setAppController($Controller){
        $this->_controller = $Controller;
    }
    
    public final  function setAppMethod($Method){
        $this->_method = $Method;
    }
    
    public final  function setAppArgs($Args){
        $this->_args = $Args;
    }
    
    public final  function setAppRequest($Request){
        $this->_request = $Request;
    }
}