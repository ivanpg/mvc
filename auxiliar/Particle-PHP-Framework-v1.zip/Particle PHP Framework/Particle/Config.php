<?php
namespace Particle\Core;
/**
 *  @name Config
 *  @category Particle\Core
 *  @author dertin
 *  
 *  @todo Buscar forma de crear una class Config con getters y setters 
 * 
 *  Esta es la configuración de nuestro framework y apps.
 *  
 **/

/* CORE CONFIG */
define('HOME_URL', 'http://127.0.0.1/ParticleFramework/');
define('BASE_URL_APPS', HOME_URL . 'Apps/');
define('DEFAULT_CONTROLLER', 'index'); // FALSE // index
define('DEFAULT_LAYOUT', 'default');
define('APP_PATH', ROOT . 'Apps'. DS);
define('ADDONS_PATH', APP_PATH . 'addons' . DS);
define('CORE_PATH', ROOT . 'Particle'. DS);
define('MAPPING_PATH', APP_PATH . 'router'. DS .'default.xml');

/*TIME ZONE*/
define('TIMEZONE', 'America/Montevideo'); // see http://www.php.net/manual/en/timezones.php
date_default_timezone_set(TIMEZONE);
/* SESSION */
define('SESSION_TIME', 10);

/* ROUTING */
define('DEFAULT_ROUTING', TRUE);
define('MAPPING_ROUTING', TRUE);
define('STRICT_ROUTING', FALSE);

/* DOCTYPE AND CHARSET */
define('CHARSET', 'UTF-8'); // ISO-8859-1
define('DOCTYPE','HTML5');  // XHTML / HTML401 / 

/* CACHE AND OUTPUT BUFFER */
define('CACHE', FALSE);
define('TIME_CACHE',30);
define('LIMIT_MB_CACHE', 1);
define('DEBUG_MODE', TRUE);
define('OUTPUT_CONTROL', FALSE);

/* DB CONFIG */
define('DB_FLAG', TRUE);
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'particle');
define('DB_CHAR', 'utf8');  //latin1
define('DB_TYPE', 'mysql'); // pgsql