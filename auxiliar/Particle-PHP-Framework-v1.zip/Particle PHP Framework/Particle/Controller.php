<?php
namespace Particle\Core;
use Particle\Core;
/**
 *  @name Controller
 *  @category Particle\Core
 *  @author dertin
 *  @abstract
 *   
 * 
 *  
 *  
 **/

abstract class Controller {

    protected $_view;
    protected $_args;
    protected $_model;
    protected $_modelAddons;
    
    private static $currentAddons;
    private static $controller;
    private static $method;

    public function __construct($isAddons = false) {
        
            self::$controller = Core\App::getInstance()->getAppController();
            self::$method = Core\App::getInstance()->getAppMethod();
            
            $this->_args = Core\App::getInstance()->getAppArgs();
            
            if($isAddons){
                $request = false;
            }else{
                $request = Core\App::getInstance()->getAppRequest();
            }
            
            $this->_view = new \Particle\Core\View(self::$controller, self::$method, $request);
            
            $this->_model = $this->loadModel(false, true);
            
            if($isAddons){
                
                self::$currentAddons = Core\App::getInstance()->getAppCurrentAddons();
                
                if(is_string(self::$currentAddons)){
                    $this->_modelAddons = $this->loadModelAddons((string)self::$currentAddons, true);
                }
                
            }
    }

    protected final function loadModel($modelName = false, $noException = false, $isAddons = false) {
        
        if (!$modelName && $isAddons == false) {
            $modelName = self::$controller;
        }
        
        if($isAddons){
            $modelClass = $modelName . 'ModelAddons';
            $pathModel = ADDONS_PATH . $modelName . DS .'models'. DS . $modelClass.'.php';
        }else{
            $modelClass = $modelName . 'Model';
            $pathModel = APP_PATH . 'models' . DS . $modelClass . '.php';
        }
        
        if (is_readable($pathModel)) {

            require_once $pathModel;
            
            if($isAddons){
                $modelNamesapce =  'Particle\\Addons\\' . $modelClass;
            }else{
                $modelNamesapce =  'Particle\\Apps\\' . $modelClass;
            }
            if (class_exists($modelNamesapce, false)) {

                $modelInstance = new $modelNamesapce;
                              
                return $modelInstance;
            } else {

                if (!$noException) {
                    
                    if($isAddons){
                        throw new \Exception('Bad Addons');
                    }else{
                        throw new \Exception('Bad Model');
                    }
                    
                } else {
                    return false;
                }
                
            }
        } else {
            if (!$noException) {
                
                if($isAddons){
                    throw new \Exception('Error Addons');
                }else{
                    throw new \Exception('Error Model');
                }
            } else {
                return false;
            }
        }
        
    }
    
    protected final function loadModelAddons($modelAddonsName, $noException=false){
       return $this->loadModel($modelAddonsName, $noException, true);
    }

    protected final function loadAddons($addons_name = false, $noException = false) {
        
        $pathPluginInit = ADDONS_PATH . $addons_name . DS .'init.php';
        
        if (is_readable($pathPluginInit)) {
            
            require_once $pathPluginInit;
            
            $classPlugin = $addons_name.'Addons';
            
            $pluginNamesapce =  'Particle\\Addons\\' . $classPlugin;

            if (class_exists($pluginNamesapce, false)) {

                $pluginInstance = new $pluginNamesapce;
                              
                return $pluginInstance;
                
            } else {

                if (!$noException) {
                    throw new \Exception('Bad Class Name Addons');
                } else {
                    return false;
                }
                
            }
            
        } else {
            
            if (!$noException) {
                throw new \Exception('Error Addons');
            } else {
                return false;
            }
            
        }
        
    }
    
    protected final function redirect($path = false, $external= false, $useJs = false) {
        /** @todo PHP redirect or JS redirect **/
        if ($path) {
            
            if($external){
                if($useJs){
                    $redirectJs = $path;
                }else{
                    header('location:' . $path);
                    exit;
                }
                
            }else{
                if($useJs){
                    $redirectJs = HOME_URL . $path;
                }else{
                    header('location:' . HOME_URL . $path);
                    exit;
                }
            }

        } else {
            if($useJs){
                   $redirectJs = HOME_URL;
            }else{
                header('location:' . HOME_URL);
                exit;
            }
            
        }
        
        if($useJs){
            $this->_view->assign($redirectJs);
            $this->_view->show('redirect');
        }else{
            throw new \Exception('Error Redirect');
        }
        
    }
       
    protected final function getLibrary($library) {
        
        $pathLibrary = APP_PATH . 'libs' . DS . $library . '.php';

        if (is_readable($pathLibrary)) {
            require_once $pathLibrary;
        } else {
            throw new \Exception('Error Library');
        }
    }

    protected final function getText($key, $array = null, $default = '', $filterXSS= false) {
        
        if(is_null($array)){
            $array = $_REQUEST;
        }
        
        if (isset($array[$key]) && !empty($array[$key])) {
            
            if($filterXSS){
                $filterText = Core\Security::filterXSS($array[$key], $default);
            }else{
                $filterText = Core\Security::cleanHtml($array[$key], $default);
            }
            
            
            return $filterText;
        }

        return $default;
    }

    protected final function getInt($key, $array = null, $default = 0){
        
        if(is_null($array)){
            $array = $_POST;
        }
        
        if (isset($array[$key]) && !empty($array[$key])){
            
            if($array != $_SESSION){
                
                if($array == $_GET){
                    $input = INPUT_GET;
                }else if($array == $_POST){
                    $input = INPUT_POST;
                }else if($array == $_COOKIE){
                    $input = INPUT_COOKIE;
                }else{
                    return false;
                }

                $array[$key] = filter_input($input, $key, FILTER_VALIDATE_INT);
            }
            $filterInt = Core\Security::filterInt($array[$key], $default);
            
            return $filterInt;
        }

        return 0;
    }

    protected final function getParam($key, $array = null, $default = false){
        
        if(is_null($array)){
            $array = $_REQUEST;
        }
        
        if (isset($array[$key])) {
            return $array[$key];
        }else{
            return $default;
        }
    }

    protected final function getSql($key, $array = null, $html = true, $default = false){
        
        if(is_null($array)){
            $array = $_REQUEST;
        }
        if (isset($array[$key]) && !empty($array[$key])) {
            return Core\Security::filterSql($array[$key], $html, $default);
        }else{
            return $default;
        }
    }

    protected final function getAlphaNum($key, $array = null, $default = ''){
        
        if(is_null($array)){
            $array = $_REQUEST;
        }
        
        if (isset($array[$key]) && !empty($array[$key])) {
            return Core\Security::filterAlphaNum($array[$key], $default);
        }else{
            return $default;
        }
        
    }
    
    protected final function uploadFile($File, $FullPatch, $allowedExts = false, $allowedTypes = false){
        
        if(!$allowedExts){
            $allowedExts = array("jpg", "jpeg", "gif", "png", "zip");
        }
        
        if(!$allowedTypes){
             $allowedTypes = array("image/gif", "image/jpeg", "image/pjpeg");
        }
        
        $extension = end(explode(".", $File["name"]));
        // TODO: add $allowedTypes
        if (($File["size"] < 20000) && in_array($extension, $allowedExts)) {
          if ($File["error"] > 0) {
                echo "Return Code: " . $File["error"] . "<br />";
            } else {
                
                echo "Upload: " . $File["name"] . "<br />";
                echo "Type: " . $File["type"] . "<br />";
                echo "Size: " . ($File["size"] / 1024) . " Kb<br />";
                echo "Temp file: " . $File["tmp_name"] . "<br />";

                if (file_exists($FullPatch . $File["name"])) {
                    echo $File["name"] . " already exists. ";
                } else {
                    move_uploaded_file($File["tmp_name"], $FullPatch . $File["name"]);
                    echo "Stored in: " . $FullPatch . $File["name"];
                    return $FullPatch . $File["name"];
                }
            }
          } else {
            echo "Error - Invalid File";
          }
    }

}