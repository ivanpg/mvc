<?php
namespace Particle\Core;
/**
 *  @name Database
 *  @category Particle\Core
 *  @author dertin
 *  
 *   
 * 
 *  
 *  
 **/

final class Database {

    static private $_PDOInstance = null;
    static private $_PDOConnect = null;
   
    public function connectDBPDODefault(){
       
       $PDOConnectNew = DB_HOST.DB_NAME.DB_USER.DB_PASS.DB_CHAR;
       
       if(self::$_PDOConnect != $PDOConnectNew){
           
           return self::_connectDBPDO();
           
       }else{
           return self::$_PDOInstance;
       }

    }

    public function connectDBPDONew($dbHost, $dbName, $dbUser, $dbPass, $dbChar){
        
       $PDOConnectNew = $dbHost.$dbName.$dbUser.$dbPass.$dbChar;
       
       if(self::$_PDOConnect != $PDOConnectNew){
                      
           return self::_connectDBPDO($dbHost, $dbName, $dbUser, $dbPass, $dbChar);
                  
       }else{
           return self::$_PDOInstance;
       }
       
    }
    
    private function _connectDBPDO($dbHost = DB_HOST, $dbName = DB_NAME, $dbUser = DB_USER, $dbPass = DB_PASS, $dbChar = DB_CHAR) {
       
        try {
            
            self::$_PDOInstance = null;

            $dsn = DB_TYPE. ':host=' . $dbHost . ';dbname=' . $dbName;
            
            $driver_options = array(\PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES ' . $dbChar);

            self::$_PDOInstance = new \PDO($dsn, $dbUser, $dbPass, $driver_options);

            self::$_PDOConnect = $dbHost.$dbName.$dbUser.$dbPass.$dbChar;;


        } catch (\PDOException $e) {
            die("PDO CONNECTION ERROR: " . $e->getMessage() . "<br/>");
        }
        
        return self::$_PDOInstance;
    }
    
    public function closeDBPDO() {
        self::$_PDOInstance = null;
        self::$_PDOConnect = null;
        return null;
    }
    
}