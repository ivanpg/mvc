<?php
namespace Particle\Core;
/**
 *  @name Debug
 *  @category Particle\Core
 *  @author dertin
 *  
 *   
 * 
 *  
 *  
 **/

final class Debug
{
    public final static function savelogfile($id, $location, $message, $filename='error.log')
    {
        // 
        // id: Error ID
        // location: Location of the file and line eg. index.php:20
        // message: Error message
        // filename: Log file path
        // 
        // Usage: Core\Debug::savelogfile(1, 'index.php:33', 'Mensaje de Error'):
        // 
        
        $file = fopen($filename,'a');

        if(!is_string($location) || !is_string($message)) {
            throw new \Exception('Incorrect datatype for save log');
        }

        fwrite($file,"[".date("r")."] Error $id ($location): $message\r\n");

        fclose($file);

    }
    
    /* TODO: file log: Add func -> contar cantidad de logs; borrar logs; buscar en archivo de log */
    
    public final static function inspect($var, $exit = false)
    {
        
        // Usage: Core\Debug::inspect($holaVar);
        
        $btr=debug_backtrace();
        
        $line=$btr[0]['line'];
        
        $file=basename($btr[0]['file']); 
        
        echo '<br><pre>';
        
        echo 'File:'.$file.':'.$line.'<br>';
        
        if (is_array($var) || is_object($var)) {
            echo htmlentities(print_r($var, true));
        }
        elseif (is_string($var)) {
            echo 'string(' . strlen($var) . ') \'' . htmlentities($var) . '\'<br>';
        }
        else {
            var_dump($var);
        }
        echo '</pre>';
 
        if ($exit) {
            exit;
        }
    }
    
}
    