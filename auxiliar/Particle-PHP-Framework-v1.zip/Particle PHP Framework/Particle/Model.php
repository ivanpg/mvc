<?php
namespace Particle\Core;
use Particle\Core;

/**
 *  @name Model
 *  @category Particle\Core
 *  @author dertin
 *  @abstract
 *   
 * 
 *  
 *  
 **/


abstract class Model
{
    private static $_DBInstance = null;
    protected $_db;
    
    public function __construct($loadModelDB = DB_FLAG) {
        
        if(DB_FLAG){
            
            if(!self::$_DBInstance){
                self::$_DBInstance = new Core\Database;
            }
            if($loadModelDB){
                $this->_db = self::$_DBInstance->connectDBPDODefault();
            }
        }else{
            $this->_db = null;
        }
        
    }
    /**
     * @todo Cambiar metodos a protected final function
     * **/
    public function connectDBNew($dbHost, $dbName, $dbUser, $dbPass, $dbChar){
        $this->_db = self::$_DBInstance->connectDBPDONew($dbHost, $dbName, $dbUser, $dbPass, $dbChar);   
    }
    
    public function connectDBDefault(){
        $this->_db = self::$_DBInstance->connectDBPDODefault();
    }
    
    public function closeDB(){
        $this->_db = self::$_DBInstance->closeDBPDO();
    }
    
}