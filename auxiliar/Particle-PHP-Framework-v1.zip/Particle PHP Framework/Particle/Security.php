<?php

namespace Particle\Core;

final class Security {

    private final static function array_map_recursive($fn, $arr,$recursive=false) {
        $rarr = array();
        
        foreach ($arr as $k => $v) {
                $rarr[$k] = is_array($v) ? self::array_map_recursive($fn, $v, true) : call_user_func($fn, $v);
        }
        
        if($recursive){
            return $rarr;
        }else{
            return $rarr[0];
        }
        
    }

    public final static function filterInt($int, $default = 0) {

        $int = (int) $int;

        if (is_int($int)) {
            return $int;
        } else {
            return $default;
        }
    }

    public final static function filterAlphaNum($str, $default = '') {

        if (is_string($str)) {
            $filterStr = (string) preg_replace('/[^A-Z0-9_]/i', '', $str);
            return trim($filterStr);
        } else {
            return $default;
        }
    }

    public final static function htmlescape($strHtml, $remove=false, $default = '', $allowable_tags=null) {

        if (is_string($strHtml)) {
            if($remove){
                $filterStrHtml = strip_tags($strHtml, $allowable_tags);
            }else{
                $filterStrHtml = htmlspecialchars($strHtml, ENT_QUOTES, CHARSET);
            }
            return $filterStrHtml;
        } else {
            return $default;
        }
    }
    
    public final static function cleanHtml($filterHtml, $remove=false, $default = '', $allowable_tags=null) {

        if (is_array($filterHtml)) {
            $filterHtml = self::array_map_recursive(array('Particle\Core\Security', 'htmlescape'), array($filterHtml, $remove, $default, $allowable_tags));
        } else if (is_string($filterHtml)) {
            $filterHtml = self::htmlescape($filterHtml, $remove, $default, $allowable_tags);
        } else {
            return $default;
        }

        return $filterHtml;
    }

    public final static function filterSql($sql, $html = true, $default = false) {

        if (isset($sql) && !empty($sql) && is_string($sql)) {

            if ($html) {
                if (DOCTYPE == 'HTML5') {
                    $iDocType = ENT_HTML5;
                } else if (DOCTYPE == 'XHTML') {
                    $iDocType = ENT_XHTML;
                } else {
                    $iDocType = ENT_HTML401;
                }

                $sql = htmlspecialchars($sql, ENT_NOQUOTES | $iDocType, CHARSET);
            }

            if (!get_magic_quotes_gpc()) {
                $sql = addslashes($sql);
            }

            return trim($sql);
        } else {
            return $default;
        }
    }

    public final static function validateEmail($email) {

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        return true;
    }

    public final static function filterXSStext($valXSS, $default = '') {

        if (!isset($valXSS) || empty($valXSS) || !is_string($valXSS)) {
            return $default;
        }

        $valTrim = trim($valXSS);

        $val = preg_replace('/([\x00-\x08][\x0b-\x0c][\x0e-\x20])/', '', $valTrim);

        $search = 'abcdefghijklmnopqrstuvwxyzáéíóúñ';
        $search .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ';
        $search .= '1234567890!@#$%^&*()';
        $search .= '~`";:?+/={}[]-_|\'\\';

        for ($i = 0; $i < strlen($search); $i++) {
            $val = preg_replace('/(&#[x|X]0{0,8}' . dechex(ord($search[$i])) . ';?)/i', $search[$i], $val);
            $val = preg_replace('/(&#0{0,8}' . ord($search[$i]) . ';?)/', $search[$i], $val);
        }

        $ra1 = Array('javascript', 'vbscript', 'expression', 'applet', 'meta', 'xml', 'blink', 'link', 'style', 'script', 'embed', 'object', 'iframe', 'frame', 'frameset', 'ilayer', 'layer', 'bgsound', 'title', 'base');
        $ra2 = Array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload');
        $ra = array_merge($ra1, $ra2);
        $found = true;

        while ($found == true) {
            $val_before = $val;
            for ($i = 0; $i < sizeof($ra); $i++) {
                $pattern = '/';
                for ($j = 0; $j < strlen($ra[$i]); $j++) {
                    if ($j > 0) {
                        $pattern .= '(';
                        $pattern .= '(&#[x|X]0{0,8}([9][a][b]);?)?';
                        $pattern .= '|(&#0{0,8}([9][10][13]);?)?';
                        $pattern .= ')?';
                    }
                    $pattern .= $ra[$i][$j];
                }
                $pattern .= '/i';
                $replacement = substr($ra[$i], 0, 2) . '<x>' . substr($ra[$i], 2);
                $val = preg_replace($pattern, $replacement, $val);
                if ($val_before == $val) {
                    $found = false;
                }
            }
        }

        $valNoXSS = strip_tags($val);

        return $valNoXSS;
    }

    public final static function filterXSS($valXSS, $default = '') {

        if (is_array($valXSS)) {
            $valXSS = self::array_map_recursive(array('Particle\Core\Security', 'filterXSStext'), array($valXSS, $default));
        } else if (is_string($valXSS)) {
            $valXSS = self::filterXSStext($valXSS, $default);
        } else {
            return $default;
        }

        return $valXSS;
    }

}