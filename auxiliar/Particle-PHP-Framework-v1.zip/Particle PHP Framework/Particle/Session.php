<?php
namespace Particle\Core;
/**
 *  @name Session
 *  @category Particle\Core
 *  @author dertin
 *  
 *   
 * 
 *  
 *  
 **/

final class Session
{
    public static function init()
    {
        session_start();
    }
    
    public static function destroy($sessionKey = false)
    {
        if($sessionKey){
            if(is_array($sessionKey)){
                for($i = 0; $i < count($sessionKey); $i++){
                    if(isset($_SESSION[$sessionKey[$i]])){
                        unset($_SESSION[$sessionKey[$i]]);
                    }
                }
            }
            else{
                if(isset($_SESSION[$sessionKey])){
                    unset($_SESSION[$sessionKey]);
                }
            }
        }
        else{
            session_destroy();
        }
    }
    
    public static function set($sessionKey, $value)
    {
        if(!empty($sessionKey)){
            $_SESSION[$sessionKey] = $value;
        }
    }
    
    public static function get($sessionKey)
    {
        if(isset($_SESSION[$sessionKey])){
            return $_SESSION[$sessionKey];
        }
    }
    
    public static function access($levelKey)
    {
        if(!Session::get('authenticated')){
            header('location:' . BASE_URL . 'error/access/5050');
            exit();
        }
        
        Session::lifeTime();
        
        if(Session::getLevel($levelKey) > Session::getLevel(Session::get('levelKey'))){
            header('location:' . BASE_URL . 'error/access/5050');
            exit();
        }
    }
    
    public static function accessView($levelKey)
    {
        if(!Session::get('authenticated')){
            return false;
        }
        
        if(Session::lifeTime(true) == false){
            return false;
        }
        
        if(Session::getLevel($levelKey) > Session::getLevel(Session::get('levelKey'))){
            return false;
        }
        
        return true;
    }
    
    public static function getLevel($levelKey)
    {
        $role = array();
        
        $role['admin'] = 3;
        $role['special'] = 2;
        $role['user'] = 1;
        
        if(!array_key_exists($levelKey, $role)){
            throw new \Exception('Error access');
        }
        else{
            return $role[$levelKey];
        }
    }
    
    
    public static function accessStrict(array $level, $noAdmin = false)
    {
        if(!Session::get('authenticated')){
            header('location:' . BASE_URL . 'error/access/5050');
            exit();
        }
        
        Session::lifeTime();
        
        if($noAdmin == false){
            if(Session::get('level') == 'admin'){
                return true;
            }
        }
        
        if(count($level)){
            if(in_array(Session::get('level'), $level)){
                return true;
            }
        }
        
        header('location:' . BASE_URL . 'error/access/5050');
        exit();
    }
    
    public static function accessViewStrict(array $level, $noAdmin = false)
    {
        if(!Session::get('authenticated')){
            return false;
        }
        
        if(Session::lifeTime(true) == false){
            return false;
        }
        
        if($noAdmin == false){
            if(Session::get('level') == 'admin'){
                return true;
            }
        }
        
        if(count($level)){
            if(in_array(Session::get('level'), $level)){
                return true;
            }
        }
        
        return false;
    }
    
    public static function lifeTime($noRedirect = false)
    {
        if(!Session::get('time') || !defined('SESSION_TIME')){
            throw new \Exception('Not defined session time'); 
        }
        
        if(SESSION_TIME == 0){
            return true;
        }
        
        if(time() - Session::get('time') > (SESSION_TIME * 60)){
            
            Session::destroy();
            
            if(!$noRedirect){
                return false;
            }else{
                header('location:' . BASE_URL . 'error/access/8080');
                exit();
            }
            
        }
        else{
            Session::set('time', time());
        }
    }
}